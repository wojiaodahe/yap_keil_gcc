#ifndef __COMMON_H__
#define __COMMON_H__

#define NULL (void *)0

#endif
