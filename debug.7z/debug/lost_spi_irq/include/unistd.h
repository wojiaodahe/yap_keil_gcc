#ifndef INCLUDE_UNISTD_H_
#define INCLUDE_UNISTD_H_

extern void ssleep(unsigned int time);
extern void msleep(unsigned int time);
extern int myprintf(char *fmt, ...);

#endif /* INCLUDE_UNISTD_H_ */
