#ifndef __MACH_S3C24XX_H__
#define __MACH_S3C24XX_H__

#define     S3C24xx_MACHINE_ID  1

#endif

